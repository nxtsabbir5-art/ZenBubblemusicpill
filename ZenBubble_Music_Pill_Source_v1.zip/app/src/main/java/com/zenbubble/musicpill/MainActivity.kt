package com.zenbubble.musicpill

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView

class MainActivity : Activity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 36, 28, 36)
            setBackgroundColor(Color.rgb(12, 12, 18))
        }

        val title = TextView(this).apply {
            text = "ZenBubble Music Pill"
            textSize = 25f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        val description = TextView(this).apply {
            text = "A minimal floating music control pill."
            textSize = 15f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 16, 0, 24)
        }
        val overlayButton = Button(this).apply {
            text = "Allow display over other apps"
            setOnClickListener {
                startActivity(
                    Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:$packageName")
                    )
                )
            }
        }
        val notificationButton = Button(this).apply {
            text = "Enable music notification access"
            setOnClickListener {
                startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
            }
        }
        val instructions = TextView(this).apply {
            text = "1. Allow display over other apps.\n2. Enable notification access.\n3. Play music in another app.\nThe pill appears when a media session is detected."
            textSize = 14f
            setTextColor(Color.LTGRAY)
            setPadding(0, 22, 0, 0)
        }

        root.addView(title)
        root.addView(description)
        root.addView(overlayButton)
        root.addView(notificationButton)
        root.addView(instructions)
        setContentView(root)
    }
}
